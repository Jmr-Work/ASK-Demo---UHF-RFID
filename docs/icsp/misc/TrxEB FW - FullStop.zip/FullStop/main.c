#include <msp430.h> 


int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	                                            /* Stop watchdog timer                                  */

    P1DIR  = 0;                                                             /* all GPIO off                                         */
    P2DIR  = 0;
    P3DIR  = 0;
    P4DIR  = 0;
    P5DIR  = 0;
    P6DIR  = 0;
    P7DIR  = 0;
    P8DIR  = 0;
    P9DIR  = 0;
    P10DIR = 0;
    P11DIR = 0;

    __bic_SR_register(GIE);                                                 /* disable interrupts                                   */

    for(;;) {
        __bis_SR_register(LPM4_bits);                                       /* go to sleep, everything off                          */
    }
}
